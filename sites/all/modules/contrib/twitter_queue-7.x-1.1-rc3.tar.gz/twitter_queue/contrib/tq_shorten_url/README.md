## Twitter Queue Shorten URL ##
This module provides an extra functionality to shorten the URLs of the nodes that are selected to be scheduled on Twitter Queue

### Requirements ###
Require Twitter [Queue module](http://drupal.org/project/twitter_queue, twitter queue)

### Supports ###
Right know only support bit.ly service shorten URL. Maybe in the furute will add another service.
